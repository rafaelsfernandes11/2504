/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package auladia2504;

import javax.swing.JOptionPane;

/**
 *
 * @author rafael.sfernandes6
 */
public class Auladia2504 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //String cpf = JOptionPane.showInputDialog(null, "Digite seu cpf ");
        // String nome = JOptionPane.showInputDialog(null, "Digite o nome ");
         //JOptionPane.showMessageDialog(null,"seu cpf e " + cpf + "seu nome " + nome);
         
         //for (int i = 0; i < 8; i++) {
             //JOptionPane.showMessageDialog(null,"repita");
         int opcao = JOptionPane.showConfirmDialog(null,"esta chovendo");
             if (opcao == 0) {
             JOptionPane.showConfirmDialog(null,"muito");
             }
             else if (opcao == 1) {
                 JOptionPane.showConfirmDialog(null,"parou");
             }
             else if (opcao == 2) {
                JOptionPane.showConfirmDialog(null,"cancelado"); 
             }
             else   {
                 
             }
           
             
    }
}
        
    
    
//}
